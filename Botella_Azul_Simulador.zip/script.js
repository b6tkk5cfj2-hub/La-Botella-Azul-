const botella=document.getElementById('botella');
const liquido=document.getElementById('liquido');
const estado=document.getElementById('estado');

let activo=false;
let inicio=0;
let cambios=0;
let direccion=0;

botella.onpointerdown=(e)=>{
botella.setPointerCapture(e.pointerId);
inicio=e.clientX;
};

botella.onpointermove=(e)=>{
let mov=e.clientX-inicio;

if(Math.abs(mov)>30){
let nueva=mov>0?1:-1;
if(nueva!==direccion){
cambios++;
direccion=nueva;
}

botella.style.transform=`rotate(${mov/5}deg)`;

if(cambios>8){
activar();
cambios=0;
}
}
};

botella.onpointerup=()=>{
botella.style.transform='rotate(0deg)';
};

function activar(){
liquido.classList.remove('incoloro');
estado.innerHTML='Estado: Azul (oxidado)';

setTimeout(()=>{
liquido.classList.add('incoloro');
estado.innerHTML='Estado: Incoloro (reducido)';
},7000);
}

liquido.classList.add('incoloro');
